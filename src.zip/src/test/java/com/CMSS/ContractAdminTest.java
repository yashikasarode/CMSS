package com.CMSS;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.CMSS.Repository.ContractorRepository;
import com.CMSS.model.ContractAdmin;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class ContractAdminTest {
	
	@Autowired
	private ContractorRepository repo;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void test() 
	{
		ContractAdmin admin=new ContractAdmin();
		admin.setAdminId(1);
		admin.setAdminName("Ram");
		admin.setPhnNumber(982345129);
		admin.setEmail("asd@gmail.com");
		admin.setPassword("1234");
		admin.setApartment("190-b veena nagar");
		admin.setCity("Indore");
		admin.setState("MP");
		admin.setPinCode(452010);
		admin.setSecurityQuestion("yes");
		
		ContractAdmin saved=repo.save(admin);
		ContractAdmin existUser = entityManager.find(ContractAdmin.class, saved.getAdminId());
		
		assertThat(existUser.getEmail()).isEqualTo(admin.getEmail());
		
	}
}
