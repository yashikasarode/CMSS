package com.CMSS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;

import com.CMSS.model.ContractAdmin;
import com.sun.istack.NotNull;
@Entity
@Table(name="RequirementDetails")
public class RequirementDetails {
	
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int requirementId;
	
	@Column(nullable=false,length=100)
	private String requirementType;
	
	@Column(nullable=false,length=100)
	private String requirementDesc;
	
	@Column(nullable=false)
	private String expectedDateOfDelivery;
	
	@Column(nullable=false,length=100)
	private String supplierType;
	
	@ManyToOne
	private ContractAdmin adminId;
	
	
	
	public RequirementDetails() {
		super();
	}

	public RequirementDetails(int requirementId, String requirementType, String requirementDesc,
			String expectedDateOfDelivery ,String supplierType) {
		super();
		this.requirementId = requirementId;
		this.requirementType = requirementType;
		this.requirementDesc = requirementDesc;
		this.expectedDateOfDelivery = expectedDateOfDelivery;
		this.supplierType=supplierType;
	}

	public int getRequirementId() {
		return requirementId;
	}

	public void setRequirementId(int requirementId) {
		this.requirementId = requirementId;
	}

	public String getRequirementType() {
		return requirementType;
	}

	public void setRequirementType(String requirementType) {
		this.requirementType = requirementType;
	}

	public String getRequirementDesc() {
		return requirementDesc;
	}

	public void setRequirementDesc(String requirementDesc) {
		this.requirementDesc = requirementDesc;
	}

	public String getExpectedDateOfDelivery() {
		return expectedDateOfDelivery;
	}


	public void setExpectedDateOfDelivery(String expectedDateOfDelivery) {
		this.expectedDateOfDelivery = expectedDateOfDelivery;
	}
	
	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	public ContractAdmin getAdminId() {
		return adminId;
	}

	public void setAdminId(ContractAdmin adminId) {
		this.adminId = adminId;
	}

	@Override
	public String toString() {
		return "RequirementDetails [requirementId=" + requirementId + ", requirementType=" + requirementType
				+ ", requirementDesc=" + requirementDesc + ", expectedDateOfDelivery=" + expectedDateOfDelivery
				+ ", supplierType=" + supplierType + ", adminId=" + adminId + "]";
	}


	

		

}