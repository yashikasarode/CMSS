package com.CMSS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SupplierRegistration")
public class SupplierReg {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int supplierId;
	
	@Column(nullable=false,unique=true,length=50 )
	private String supplierName;
	
	@Column(nullable=false,length=50 )
	private String Company;
	
	@Column(nullable=false,length=50 )
	private long phnNumber;
	
	@Column(nullable=false,unique=true )
	private String email;
	
	@Column(nullable=false,unique=true,length=64 )
	private String password;
	
	@Column(nullable=false,length=50 )
	private String apartment;
	
	@Column(nullable=false,length=25 )
	private String city;
	
	@Column(nullable=false,length=20)
	private String state;
	
	@Column(nullable=false,length=6)
	private int pinCode;
	
	@Column(nullable=false,length=100 )
	private String securityQuestion;
	
	
	
	
	public SupplierReg() {
		super();
	}

	public SupplierReg(int supplierId, String supplierName, String company, long phnNumber, String email,
			String password, String apartment, String city, String state, int pinCode, String securityQuestion) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		Company = company;
		this.phnNumber = phnNumber;
		this.email = email;
		this.password = password;
		this.apartment = apartment;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.securityQuestion = securityQuestion;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public long getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(long phnNumber) {
		this.phnNumber = phnNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getApartment() {
		return apartment;
	}

	public void setApartment(String apartment) {
		this.apartment = apartment;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	@Override
	public String toString() {
		return "SupplierRegistration [supplierId=" + supplierId + ", supplierName=" + supplierName + ", Company="
				+ Company + ", phnNumber=" + phnNumber + ", email=" + email + ", password=" + password + ", apartment="
				+ apartment + ", city=" + city + ", state=" + state + ", pinCode=" + pinCode + ", securityQuestion="
				+ securityQuestion + "]";
	}

}
