package com.CMSS.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "contract_registration")

public class ContractAdmin {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int adminId;
	
	@Column(nullable=false,unique=true,length=50 )
	private String adminName;
	
	@Column(nullable=false,unique=true,length=10 )
	private long phnNumber;
	
	@Column(nullable=false,unique=true,length=50)
	private String email;
	
	@Column(nullable=false,unique=true,length=64)
	private String password;
	
	@Column(nullable=false,length=50 )
	private String apartment;
	
	@Column(nullable=false,length=50)
	private String city;
	
	@Column(nullable=false,length=20)
	private String state;
	
	@Column(nullable=false,length=6 )
	private int pinCode;
	
	@Column(nullable=false,length=50)
	private String securityQuestion;
	
	public ContractAdmin(int adminId, String adminName, long phnNumber, String email, String password,
			String apartment, String city, String state, int pinCode, String securityQuestion) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.phnNumber = phnNumber;
		this.email = email;
		this.password = password;
		this.apartment = apartment;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.securityQuestion = securityQuestion;
	}

	
	public ContractAdmin() {
		super();
	}


	@Override
	public String toString() {
		return "AdminRegistration [adminId=" + adminId + ", adminName=" + adminName + ", phnNumber=" + phnNumber
				+ ", email=" + email + ", password=" + password + ", apartment=" + apartment + ", city=" + city
				+ ", state=" + state + ", pinCode=" + pinCode + ", securityQuestion=" + securityQuestion + "]";
	}

	public int getAdminId() {
		return adminId;
	}
	
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public long getPhnNumber() {
		return phnNumber;
	}
	
	public void setPhnNumber(long phnNumber) {
		this.phnNumber = phnNumber;
	}

	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getApartment() {
		return apartment;
	}

	public void setApartment(String apartment) {
		this.apartment = apartment;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	
	

}

