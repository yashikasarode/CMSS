package com.CMSS.service;

import com.CMSS.model.ContractAdmin;
import com.CMSS.model.RequirementDetails;

public interface ContractorInterface {

	public ContractAdmin saveContractor(ContractAdmin contractAdmin);
	
	public RequirementDetails saveRequirement(RequirementDetails requirementDetails);
	
	public RequirementDetails viewRequirementById(int requirementId);
}
