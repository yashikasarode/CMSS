package com.CMSS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CMSS.Repository.ContractorRepository;
import com.CMSS.Repository.RequirementRepository;
import com.CMSS.model.ContractAdmin;
import com.CMSS.model.RequirementDetails;

@Service
public class ContractorImpll implements ContractorInterface {
	
	@Autowired
	private RequirementRepository repo;
	
	@Autowired
	private ContractorRepository crepo;
	
	@Override
	public ContractAdmin saveContractor(ContractAdmin contractAdmin) {
		// TODO Auto-generated method stub
		return crepo.save(contractAdmin);
	}

	
	

	@Override
	public RequirementDetails saveRequirement(RequirementDetails requirementDetails) {
		// TODO Auto-generated method stub
		
		return repo.save(requirementDetails);
	}


	@Override
	public RequirementDetails viewRequirementById(int requirementId) {
		// TODO Auto-generated method stub
		
		return repo.findById(requirementId).get();
		
	}


	
	
}
