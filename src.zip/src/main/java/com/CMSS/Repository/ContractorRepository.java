package com.CMSS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.CMSS.model.ContractAdmin;

public interface ContractorRepository extends CrudRepository<ContractAdmin, Integer> {

}
