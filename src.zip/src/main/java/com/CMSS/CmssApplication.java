package com.CMSS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmssApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmssApplication.class, args);
	}

}
