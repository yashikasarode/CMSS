package com.CMSS.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.CMSS.Repository.ContractorRepository;
import com.CMSS.model.RequirementDetails;
import com.CMSS.service.ContractorImpll;
import com.CMSS.model.ContractAdmin;
@Controller
public class HomeController {
	
	@Autowired
	private ContractorImpll impl;
	
	
	
	@RequestMapping("/showContractor")
	public String showContract() 
	{
		return "conReg";
	}
	
	@RequestMapping(value= "/savCon" , method=RequestMethod.POST)
	public String saveContractor(@ModelAttribute("contractAdmin")ContractAdmin contractAdmin , ModelMap modelMap)
	{
		System.out.println("hello");
		ContractAdmin msg = impl.saveContractor(contractAdmin);
		String msg1 ="Registration saved with "+contractAdmin.getAdminId();
		modelMap.addAttribute("msgg", msg1);
		
		return "signUpSuccessAdmin";
	}
	
	
	@RequestMapping("/showCreate")
	public String showCreate() {
		return "createRequirement";
	}
	

	
	@RequestMapping("/savReq")
	public String saveRequirement(@ModelAttribute("requirementDetails") RequirementDetails requirementDetails
			, ModelMap modelMap ) 
	{
		RequirementDetails saveRequirement = impl.saveRequirement(requirementDetails);
		String msg="Requirement created for id"+ saveRequirement.getAdminId();
		modelMap.addAttribute("msg", msg);
		return "createRequirement";
		
	}
	
	
	

}
